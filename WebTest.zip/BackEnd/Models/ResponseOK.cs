﻿namespace BackEnd.Models
{
    public class ResponseOK : ResponseBase
    {
        public dynamic? data { get; set; }
    }
}
