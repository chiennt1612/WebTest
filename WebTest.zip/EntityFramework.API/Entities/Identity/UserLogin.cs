﻿using Microsoft.AspNetCore.Identity;

namespace EntityFramework.API.Entities.Identity
{
    public class UserLogin : IdentityUserLogin<long>
    {
    }
}
