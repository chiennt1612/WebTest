﻿using Microsoft.AspNetCore.Identity;

namespace EntityFramework.API.Entities.Identity
{
    public class RoleClaim : IdentityRoleClaim<long>
    {
    }
}
